"use client";

export default function GradientBackground() {
  return (
    <div
      className="animated-gradient"
      aria-hidden="true"
    ></div>
  );
}
