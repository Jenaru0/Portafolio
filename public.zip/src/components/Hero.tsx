"use client";

import Avatar from "@/components/Avatar";
import GradientBackground from "@/components/Background";
import ParticlesBackground from "@/components/ParticlesBackground";
import { motion } from "framer-motion";
import { FaLinkedin, FaGithub, FaEnvelope } from "react-icons/fa";
import SectionWrapper from "./ui/SectionWrapper";

const phraseVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export default function Hero() {
  return (
    <SectionWrapper
      id="hero"
      className="relative h-screen snap-start flex flex-col items-center justify-center text-center text-white px-4 bg-gradient-hero">
      {/* Fondo animado */}
      <GradientBackground />
      <ParticlesBackground />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black opacity-60 -z-10"></div>

      {/* Contenido principal */}
      <div className="relative z-10">
        <div className="flex justify-center">
          <Avatar />
        </div>
        <motion.h1
          className="text-4xl font-bold drop-shadow-lg"
          variants={phraseVariants}
          initial="hidden"
          animate="visible"
          transition={{ duration: 1 }}
        >
          Hola, soy <span className="text-secondary">Jhonatan Napanga</span>
        </motion.h1>
        <motion.p
          className="text-xl mt-2 drop-shadow-lg"
          variants={phraseVariants}
          initial="hidden"
          animate="visible"
          transition={{ duration: 1, delay: 0.5 }}
        >
          Estudiante de Ingeniería de Sistemas | Desarrollador Web
        </motion.p>

        {/* Información de contacto */}
        <motion.div
          className="flex gap-6 mt-6 justify-center items-center"
          initial="hidden"
          animate="visible"
          transition={{ duration: 1, delay: 0.8 }}
        >
          {/* LinkedIn */}
          <a
            href="https://www.linkedin.com/in/jhonatan-jesus-napanga-ruiz"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
            className="text-white hover:text-secondary transition-all duration-300 text-2xl hover:scale-110"
          >
            <FaLinkedin />
          </a>

          {/* GitHub */}
          <a
            href="https://github.com/Jenaru0"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="GitHub"
            className="text-white hover:text-secondary transition-all duration-300 text-2xl hover:scale-110"
          >
            <FaGithub />
          </a>

          {/* Correo con función de copiado */}
          <button
            aria-label="Copiar correo"
            className="text-white hover:text-secondary transition-all duration-300 text-2xl hover:scale-110"
            onClick={() => {
              navigator.clipboard.writeText("jhonatanjesusnapangaruiz@gmail.com");
              alert("Correo copiado al portapapeles 📩");
            }}
          >
            <FaEnvelope />
          </button>
        </motion.div>

        {/* Botón de Ver Proyectos */}
        <motion.button
          onClick={() =>
            document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })
          }
          className="mt-6 px-6 py-3 bg-secondary text-white font-semibold rounded-lg hover:bg-primary hover:text-secondary transition-all shadow-md hover:shadow-lg active:scale-95"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
        >
          Ver Proyectos
        </motion.button>
      </div>
    </SectionWrapper>
  );
}
