// src/app/contacto/page.tsx
const ContactoPage = () => {
    return (
      <div>
        <h1>Contacto</h1>
        <p>Esta es la página de contacto.</p>
      </div>
    );
  };
  
  export default ContactoPage;